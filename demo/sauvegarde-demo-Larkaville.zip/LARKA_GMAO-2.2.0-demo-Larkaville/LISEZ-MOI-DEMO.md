# Larka 2.2.0 — sauvegarde de démonstration « Ville de Larkaville »

Une commune fictive de 12 bâtiments, **cinq ans d'activité** (octobre 2021 → 14 octobre 2026, 17 h 40) dans
**tous** les modules de Larka, sept modules complémentaires installés, des comptes pour chaque rôle.
Tout est inventé : personnes, entreprises, numéros, adresses.

## Contenu du paquet

| Fichier | Rôle |
|---|---|
| `LARKA_GMAO-2.2.0-demo-Larkaville-sqlite.db.gz` | La base SQLite (25,4 Mo décompressée) |
| `LARKA_GMAO-2.2.0-demo-Larkaville-fichiers.tar.gz` | Les fichiers hors base : fonds de plans, modules installés, thèmes et langues, photos des procédures d'urgence, listes des modules |
| `LARKA_GMAO-2.2.0-demo-Larkaville-postgresql.sql.gz` | La même base pour PostgreSQL (`pg_dump` en SQL, sans propriétaire ni droits) |
| `recaler-dates.php` | Recale la démonstration sur la date du jour (voir plus bas) |
| `comptes-demo.csv` | Les 54 comptes (Excel : séparateur `;`, UTF-8) |
| `SHA256SUMS` | Empreintes des fichiers |

**Prérequis** : Larka **2.2.0** (ou 2.1.1 : même schéma 13 — une 2.1.0 perdrait des champs des bordereaux
d'archives et la TVA chauffage), PHP ≥ 8.1, modules activés (`"extensions": {"actif": true}` dans `config.json`).
Sous Windows, `Larka.cmd` fournit PHP et fait tout le reste (voir ci-dessous).
PostgreSQL : version 12 ou plus récente (dump produit avec PostgreSQL 16).

## Ce qu'elle contient

| Domaine | Volume |
|---|---|
| Comptes | 54 (5 gestionnaires, 11 visionneurs dont 7 techniciens, 38 demandeurs ; 3 désactivés) |
| Inventaire | 1 833 biens (163 sortis : dons, ventes, recyclage), 404 équipements, 116 articles de stock |
| Maintenance | 3 644 demandes, 4 602 interventions (curatives, préventives, contrôles réglementaires), 2 261 lignes de pièces, 358 devis, 1 315 factures |
| Contrats | 32 (maintenance, contrôles, énergie avec tarifs, location) — dont des expirés et des échéances proches |
| Gestion matériel | 689 immobilisations avec amortissements et clôtures ; 644 déclarations d'inventaire (campagnes 2022 → 2026) |
| Énergie | 36 compteurs (électricité dont un tarif HTA, gaz, eau, réseau de chaleur), 3 754 relevés et factures, 72 factures PDF, CO₂ calculé |
| Mobilité | 159 trajets déclarés, millésimes de facteurs figés 2024 → 2026 |
| Archives | 164 boîtes, 2 018 dossiers, 37 bordereaux, 120 demandes d'archives |
| Plans | 12 bâtiments, 25 étages avec fond de plan, 982 éléments (pièces, personnes, équipements, DAE…), 400 liens vers les fiches |
| Documents | 1 185 pièces jointes (photos d'intervention, bons, contrats, notices) |
| Modules | Clés (216), Contrôles (59), Formations et habilitations (39), Prestataires (25), Réservation de bornes de recharge (1 046 créneaux), Démo image (8), Moteur d'apparence |
| Divers | 2 thèmes, 2 langues (anglais — remis à niveau en 4.2.0 par Larka 2.2.0 dès la première utilisation —, espagnol), 9 catégories de procédures d'urgence, notes d'information, historique des suppressions, journal applicatif des 30 derniers jours (9 335 entrées) |

Données fictives : domaine `larkaville.test` (réservé, jamais routé), téléphones dans les tranches que l'ARCEP
réserve à la fiction (01 99 00…, 06 39 98…), entreprises imaginaires, SIRET invalides. Les PDF et les photos
sont des illustrations générées. Aucun envoi de courriel n'est configuré.

## Comptes

Mot de passe commun : **`Larka2026!`** — à changer si l'instance est accessible par d'autres que vous.

L'écran de connexion de la démonstration **affiche** l'identifiant `claire.moreau` et ce mot de passe, avec un bouton
« Se connecter avec ce compte » et un accès par profil (demandeur, visionneur…) : un clic remplit le formulaire.
L'encadré disparaît dès que le mot de passe de `claire.moreau` est changé, et n'apparaît jamais sur une instance
multi-tenant. Il suppose la liste des comptes dans `data/demo/comptes-demo.csv`, que `Larka.cmd demo` et
`./start.sh demo` y copient ; après une restauration à la main, copiez-la vous-même (`mkdir -p data/demo && cp
comptes-demo.csv data/demo/`).

| Identifiant | Rôle | Pour montrer |
|---|---|---|
| `claire.moreau` | Gestionnaire — responsable du patrimoine bâti | Le parcours principal : tableau de bord, demandes, interventions, contrats, énergie |
| `admin` | Gestionnaire — administration | Configuration, comptes, modules |
| `thomas.lefevre`, `sophie.renaud`, `julien.garnier` | Gestionnaires | Patrimoine, gestion technique, informatique |
| `isabelle.fontaine` | Visionneur — directrice générale des services | La consultation sans modification |
| `marc.dubois`, `nicolas.girard`, `antoine.roux`… | Visionneur + profil technicien | Le point de vue des agents techniques |
| `camille.martin` | Demandeur | Déposer une demande, suivre son historique, l'annuaire |
| `stephanie.brun` | Demandeur + consultation Énergie, Bilan carbone, Statistiques | Les onglets ouverts en lecture à un demandeur |
| `olivier.blanc` | Demandeur + consultation Plans, Biens | Idem, autre combinaison |
| `valerie.rousseau` | Demandeur — archiviste | Les demandes d'archives |

La liste complète est dans `comptes-demo.csv`.

## Restaurer — Windows (le plus simple)

1. Décompressez Larka 2.2.0 dans un dossier local, par exemple `C:\Larka` (pas dans `Program Files`, ni dans
   un dossier synchronisé par OneDrive, ni sur un partage réseau).
2. La démonstration est **déjà dans le dossier `demo\`** de Larka (archive GitHub ou complète). Sinon, posez
   l'archive telle quelle (`…-sauvegarde-demo-Larkaville.zip`) dans `demo\` ou dans le dossier de Larka.
3. Double-cliquez sur **`Larka.cmd`**. Au premier lancement, il installe PHP, fait accepter la licence, puis
   **propose la démonstration** : répondez `O`. Le navigateur s'ouvre ; connectez-vous en
   `claire.moreau` / `Larka2026!`.

Sur une installation déjà en service : `Larka.cmd demo` (il cherche l'archive dans le dossier de Larka, son
dossier `demo\`, le dossier parent, Téléchargements et le Bureau), ou `Larka.cmd demo C:\chemin\archive.zip`. Il arrête Larka
s'il tourne, **met la base actuelle de côté** dans `data\backups\avant-demo-….db`, pose la base et les
fichiers, active les modules, garde le journal 30 jours, **recale les dates** sur aujourd'hui, puis redémarre.
La liste des comptes est copiée dans `data\demo\comptes-demo.csv`.

## Restaurer — Linux (le plus simple)

1. Installez Larka 2.2.0 comme d'habitude : `./start.sh install` (PostgreSQL).
2. La démonstration est **déjà dans le dossier `demo/`** de Larka (dépôt GitHub ou archive complète). Sinon,
   posez l'archive telle quelle (`…-sauvegarde-demo-Larkaville.zip`) dans `demo/` ou dans le dossier de Larka.
3. À la fin de l'installation — ou au premier `./start.sh start` — **la démonstration est proposée** :
   répondez `O` (une seule fois : un « non » est retenu). Connectez-vous en `claire.moreau` / `Larka2026!`.

Sur une installation déjà en service : `./start.sh demo` (ou `./start.sh demo /chemin/archive.zip`). Il arrête
le serveur de développement s'il tourne, **met la base actuelle de côté** dans `data/backups/avant-demo-…`
(`pg_dump` pour PostgreSQL), charge la base de démonstration (PostgreSQL ou SQLite, selon `config.json`) en
une seule transaction — au moindre échec, la base reste telle qu'elle était —, pose les fichiers, active les
modules, garde le journal 30 jours, **recale les dates** sur aujourd'hui et redémarre le serveur s'il tournait.
Pour PostgreSQL, il faut le client `psql` (et `pg_dump` si la base contient déjà des données), et une base
appartenant au rôle de Larka — ce que prépare `./start.sh install`.

## Restaurer — installation SQLite (à la main)

> Une instance **dédiée** aux démonstrations est recommandée : la restauration remplace la base et l'état des modules.

1. Partez d'une installation Larka **2.2.0** configurée et fonctionnelle (`./start.sh setup` ou `deploy/install.sh`),
   puis **arrêtez** le serveur.
2. Mettez de côté la base actuelle si elle compte : `data/gmao.db` (et `data/gmao.db-wal`, `-shm` s'ils existent).
3. Posez la base de démonstration et retirez les fichiers annexes :
   ```bash
   gunzip -c LARKA_GMAO-2.2.0-demo-Larkaville-sqlite.db.gz > data/gmao.db
   rm -f data/gmao.db-wal data/gmao.db-shm data/.schema/*.flag
   ```
4. Déposez les fichiers, depuis la racine de Larka :
   ```bash
   tar -xzf LARKA_GMAO-2.2.0-demo-Larkaville-fichiers.tar.gz
   ```
   (écrit `data/plans/`, `data/extensions/`, `data/thematiques/`, `data/urgences/`, `extensions/config/larka.*/`)
5. Dans `config.json` : `"extensions": {"actif": true}` ; conseillé : `"logs": {"rotation_jours": 30}` — avec la
   rétention par défaut (14 jours), le journal de démonstration est en partie purgé à la première requête.
6. Rendez les fichiers au compte du serveur web, par exemple `chown -R www-data: data extensions/config`.
7. *(Facultatif, conseillé)* recalez les dates sur aujourd'hui : `php recaler-dates.php data/gmao.db --fichiers=.`
8. Démarrez, connectez-vous en `claire.moreau` / `Larka2026!`.

`Larka.cmd demo` (Windows) et `./start.sh demo` (Linux) font ces étapes à votre place (sections précédentes).

## Restaurer — PostgreSQL (à la main)

1. Créez une base vide appartenant au rôle de Larka (un rôle ordinaire suffit) :
   ```sql
   CREATE DATABASE larka_demo OWNER larka ENCODING 'UTF8' TEMPLATE template0;
   ```
2. Chargez le dump :
   ```bash
   gunzip -c LARKA_GMAO-2.2.0-demo-Larkaville-postgresql.sql.gz \
     | psql -h 127.0.0.1 -U larka -d larka_demo -v ON_ERROR_STOP=1
   ```
3. `config.json` → `"base_de_donnees": {"driver": "pgsql", "host": "127.0.0.1", "port": 5432, "dbname": "larka_demo", "user": "larka"}` ;
   mot de passe dans `.env` : `GMAO_DB_PASSWORD=…`.
4. Fichiers : étapes 4 à 6 ci-dessus ; supprimez `data/.schema/*.flag`.
5. *(Facultatif)* `php recaler-dates.php "pgsql:host=127.0.0.1;port=5432;dbname=larka_demo" --utilisateur=larka --mot-de-passe=… --fichiers=.`

Autre chemin : restaurer la version SQLite, puis **Configuration → Serveur → Migration** vers PostgreSQL — depuis
la 2.1.1, elle emporte toutes les tables (c'est ainsi qu'a été produit le dump fourni : 40 tables).

## Multi-tenant

La démonstration vise une installation mono-tenant. Pour l'installer comme client d'une instance multi-tenant :
placez la base au chemin du tenant (SQLite) ou chargez le dump dans sa base (PostgreSQL), et déplacez le contenu
de `data/extensions/` (`code/`, `paquets/`, `etat.json`) dans `data/extensions/tenants/<clé du tenant>/`. Les
photos d'urgence peuvent rester dans `data/urgences/` : elles rejoignent le dossier du client à la première
consultation.

⚠️ L'**import** de l'écran Super Admin n'importe jamais les comptes (choix de conception : les comptes de la base
cible sont conservés). Importée ainsi, la démonstration n'aurait donc aucun de ses 54 comptes : préférez la pose
directe du fichier ou du dump.

## Recaler les dates

La démonstration « s'arrête » le 14 octobre 2026 à 17 h 40. Restaurée plus tard, elle vieillit : rien de récent au
tableau de bord, des demandes en retard de plusieurs semaines, un journal purgé par la rétention.
`recaler-dates.php` décale toute la base d'un **nombre entier de semaines** (les jours de la semaine sont conservés),
arrondi vers le passé pour qu'aucune activité ne se retrouve dans le futur :

```bash
php recaler-dates.php data/gmao.db --fichiers=.                      # sur aujourd'hui
php recaler-dates.php data/gmao.db --au=2027-03-15 --fichiers=.      # sur une date choisie
php recaler-dates.php data/gmao.db --simuler                         # voir sans rien écrire
```

- Serveur **arrêté**, sur une base sauvegardée. Une seule transaction : en cas d'échec, rien n'est modifié.
- Relançable : la base mémorise sa date de fin (`demo_ancre`) et seul l'écart est appliqué. Passez `--fichiers`
  dès le premier lancement (dates d'installation des modules).
- Décalés : toutes les dates et date-heures (y compris dans les textes, commentaires et le journal), les numéros
  datés (`INT-AAAAMM-…`, `FAC-AAAAMM-…`, `CT-AAAA-…`, `IMM-…`, `BC-…`, `M-…`, `BE/BV-…`, `V-…`), les colonnes
  « année » (facteurs carbone et mobilité, exercices, révision des archives).
- Non décalés : le contenu des archives (dossiers de 2000 à 2025, documents historiques), les années écrites en
  toutes lettres dans un libellé, le contenu des PDF et des photos.
- Un décalage de plusieurs mois déplace aussi les saisons (pics de chauffage). Pour un écart de plus d'un an,
  visez la même époque de l'année.

## Vérifications faites

- Chaque écran de chaque rôle parcouru dans un navigateur (6 comptes types, 8 à 27 onglets chacun) : aucune
  erreur JavaScript, aucune erreur serveur.
- 61 routes de lecture de l'API appelées avec 10 comptes : toutes répondent, hors les refus attendus selon le rôle (403).
- PostgreSQL : dump rechargé par un rôle ordinaire, puis 67 routes comparées une à une avec la version SQLite —
  réponses identiques (seuls diffèrent les avertissements sur les droits des fichiers, propres à chaque serveur).
- Recalage testé à −7, +5 et +52 semaines (SQLite) et à +5 et +52 semaines (PostgreSQL) : aucune trace
  postérieure à la nouvelle fin, numéros toujours uniques ; application parcourue sans erreur sur une base recalée.
- Windows : démonstration posée par `Larka.cmd` avec PHP 8.3 pour Windows (exécuté sous Wine, chemins
  `C:\…`), puis 4 rôles parcourus dans le navigateur (aucune erreur), lectures de l'API pour 4 comptes, et
  écritures éprouvées (documents, fonds de plan, médias, modules, réglages, migration, sauvegarde).

## Empreintes

Voir `SHA256SUMS` (`sha256sum -c SHA256SUMS`).
