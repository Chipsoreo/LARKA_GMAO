<?php
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  Larka — démonstration « Ville de Larkaville » : recaler les dates
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  La base de démonstration raconte cinq ans d'activité qui s'arrêtent au
 *  14 octobre 2026. Restaurée plus tard, elle vieillit : plus rien « cette
 *  semaine », des demandes en retard de plusieurs mois, un journal purgé par
 *  la rétention. Ce script décale TOUTES les dates de la base d'un nombre
 *  entier de semaines (les jours de la semaine sont conservés : pas
 *  d'intervention un dimanche), pour que la démonstration se termine à la
 *  date voulue — aujourd'hui, par défaut.
 *
 *  Ce qui est décalé :
 *    • toute date ou date-heure ISO (2026-10-14, 2026-10-14 17:40:00,
 *      2024-01-15T09:30:00+01:00), y compris dans un texte ou un JSON
 *      (journal, historiques, commentaires) ;
 *    • les dates françaises écrites dans un texte (31/12/2026) ;
 *    • les numéros datés : INT-AAAAMM-…, FAC-AAAAMM-… (en mois), CT-AAAA-…,
 *      IMM-AAAA-…, BC-AAAA-…, M-AAAA-…, BE/BV-AAAA-…, V-AAAA-… (en années) ;
 *    • les colonnes « année » (facteurs carbone et mobilité, exercice
 *      comptable, année de révision des archives), de l'arrondi en années ;
 *    • avec --fichiers : la date d'installation des modules (etat.json).
 *
 *  Ce qui ne l'est pas : le contenu des archives (dossiers de 2000 à 2025 :
 *  ce sont des documents historiques), les années écrites en toutes lettres
 *  dans un libellé, le contenu des PDF et des photos joints.
 *
 *  Un décalage de plusieurs mois déplace aussi les saisons : les pics de
 *  chauffage suivent leurs dates. Au-delà d'un an, préférez des multiples
 *  de 52 semaines (--au à la même époque de l'année).
 *
 *  « Larka.cmd demo » (Windows) et « ./start.sh demo » (Linux) l'exécutent
 *  d'eux-mêmes après la pose.
 *
 *  Usage :
 *    php recaler-dates.php data/gmao.db [--au=AAAA-MM-JJ] [--fichiers=.] [--simuler]
 *    php recaler-dates.php "pgsql:host=127.0.0.1;port=5432;dbname=larka_demo" \
 *        --utilisateur=larka --mot-de-passe=… [--au=…] [--fichiers=…] [--simuler]
 *
 *  À lancer serveur ARRÊTÉ (ou sans utilisateur connecté), sur une base
 *  sauvegardée. Relancer plus tard est sans risque : la base mémorise sa date
 *  de référence (Configuration « demo_ancre ») et seul l'écart est appliqué.
 * ═══════════════════════════════════════════════════════════════════════════
 */

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
date_default_timezone_set('Europe/Paris');

const ANCRE_ORIGINE = '2026-10-14 17:40:00';

// ── Arguments ─────────────────────────────────────────────────────────────
$cible = null; $opt = [];
foreach (array_slice($argv, 1) as $a) {
    if (preg_match('/^--([a-z-]+)(?:=(.*))?$/', $a, $m)) $opt[$m[1]] = $m[2] ?? true;
    elseif ($cible === null) $cible = $a;
}
if ($cible === null) {
    fwrite(STDERR, "Usage : php recaler-dates.php <fichier .db | dsn pgsql:…> [--au=AAAA-MM-JJ] [--fichiers=<racine Larka>] [--simuler]\n");
    exit(2);
}
$simuler = isset($opt['simuler']);

try {
    if (str_starts_with($cible, 'pgsql:')) {
        // Sans --mot-de-passe : libpq lit PGPASSWORD (ou ~/.pgpass). C'est ainsi
        // que « ./start.sh demo » le transmet, hors de la ligne de commande.
        $pdo = new PDO($cible, (string)($opt['utilisateur'] ?? ''), isset($opt['mot-de-passe']) ? (string)$opt['mot-de-passe'] : null);
    } else {
        if (!is_file($cible)) throw new RuntimeException("Fichier introuvable : $cible");
        $pdo = new PDO('sqlite:' . $cible);
        $pdo->exec('PRAGMA busy_timeout = 5000');
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    fwrite(STDERR, "Connexion impossible : " . $e->getMessage() . "\n");
    exit(1);
}
$pg = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'pgsql';
$q  = fn(string $n): string => '"' . str_replace('"', '""', $pg ? strtolower($n) : $n) . '"';

// ── Décalage ──────────────────────────────────────────────────────────────
$tableConfig = $pg ? 'configuration' : 'Configuration';
$ancre = ANCRE_ORIGINE;
try {
    $st = $pdo->prepare("SELECT " . $q('Valeur') . " FROM " . $q('Configuration') . " WHERE " . $q('Cle') . " = 'demo_ancre'");
    $st->execute();
    $v = $st->fetchColumn();
    if (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $v)) $ancre = $v;
} catch (Throwable $e) { /* clé absente : ancre d'origine */ }

$au = isset($opt['au']) && is_string($opt['au']) ? $opt['au'] : date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $au) || strtotime($au) === false) {
    fwrite(STDERR, "--au attend une date AAAA-MM-JJ.\n"); exit(2);
}
$tAncre = new DateTimeImmutable($ancre);
$tCible = new DateTimeImmutable($au . ' ' . $tAncre->format('H:i:s'));
$jours  = (int)$tAncre->diff($tCible)->format('%r%a');
// Semaines entières, arrondies VERS LE PASSÉ : la démonstration ne doit jamais
// « se terminer » après la date visée (activité future impossible).
$semaines = intdiv($jours, 7) - (($jours < 0 && $jours % 7 !== 0) ? 1 : 0);
$N  = $semaines * 7;
$dm = (int)round($N / 30.436875);   // mois, pour les numéros AAAAMM
$dy = (int)round($N / 365.2425);    // années, pour les numéros AAAA et les colonnes « année »
$nouvelleAncre = $tAncre->modify("$N days")->format('Y-m-d H:i:s');

echo "Base            : $cible\n";
echo "Référence       : $ancre\n";
echo "Visée           : $au\n";
printf("Décalage        : %+d jours (%+d semaines) · numéros %+d mois · années %+d\n", $N, $semaines, $dm, $dy);
echo "Nouvelle fin    : $nouvelleAncre\n";
if ($N === 0) { echo "Rien à faire.\n"; exit(0); }

// ── Transformations ───────────────────────────────────────────────────────
$decalerJour = function (int $a, int $m, int $j) use ($N): ?array {
    if ($a < 1990 || $a > 2099 || $m < 1 || $m > 12 || $j < 1 || $j > 31 || !checkdate($m, $j, $a)) return null;
    $d = (new DateTimeImmutable(sprintf('%04d-%02d-%02d', $a, $m, $j)))->modify("$N days");
    return [(int)$d->format('Y'), (int)$d->format('m'), (int)$d->format('d')];
};
$iso = '/(?<![\d\/-])(\d{4})-(\d{2})-(\d{2})(?![\d-])/';
// « 31/12/2026 », et « 31\/12\/2026 » tel que json_encode l'écrit dans le journal.
$fr  = '~(?<![\d/\\\\])(\d{2})(\\\\?/)(\d{2})\2(\d{4})(?![\d/\\\\])~';
$decalerDates = function (string $s) use ($iso, $fr, $decalerJour): string {
    if (!preg_match('~\d{4}-\d{2}-\d{2}|\d{2}\\\\?/\d{2}\\\\?/\d{4}~', $s)) return $s;
    $s = preg_replace_callback($iso, function ($m) use ($decalerJour) {
        $r = $decalerJour((int)$m[1], (int)$m[2], (int)$m[3]);
        return $r ? sprintf('%04d-%02d-%02d', ...$r) : $m[0];
    }, $s);
    return preg_replace_callback($fr, function ($m) use ($decalerJour) {
        $r = $decalerJour((int)$m[4], (int)$m[3], (int)$m[1]);
        return $r ? sprintf('%02d%s%02d%s%04d', $r[2], $m[2], $r[1], $m[2], $r[0]) : $m[0];
    }, $s);
};
// Numéros datés. INT/FAC : préfixes distinctifs, corrigés partout (journal,
// noms de fichiers…) ; les autres seulement dans leur propre colonne.
$decalerMois = function (int $a, int $m) use ($dm): string {
    $t = $a * 12 + ($m - 1) + $dm;
    return sprintf('%04d%02d', intdiv($t, 12), $t % 12 + 1);
};
$numerosMois = function (string $s) use ($dm, $decalerMois): string {
    if ($dm === 0 || !preg_match('/\b(?:INT|FAC)-\d{6}-/', $s)) return $s;
    return preg_replace_callback('/\b(INT|FAC)-(\d{4})(\d{2})-(\d+)\b/', function ($m) use ($decalerMois) {
        $mois = (int)$m[3];
        return ($mois >= 1 && $mois <= 12) ? $m[1] . '-' . $decalerMois((int)$m[2], $mois) . '-' . $m[4] : $m[0];
    }, $s);
};
$numeroAnnee = function (string $s, string $prefixes) use ($dy): string {
    if ($dy === 0) return $s;
    return preg_replace_callback('/^((?:' . $prefixes . ')-)(\d{4})(-.*)$/', fn($m) => $m[1] . ((int)$m[2] + $dy) . $m[3], $s);
};
$colonnesNumeroAnnee = [   // table => [colonne => préfixes]
    'contrats'          => ['numero' => 'CT'],
    'gestionmateriel'   => ['numeroimmo' => 'IMM', 'bondecommande' => 'BC', 'numeromandat' => 'M'],
    'archivesbordereau' => ['numero' => 'BE|BV'],
    'archivesboite'     => ['numeroversement' => 'V'],
];
$colonnesAnnee = [         // table => colonnes « année » (entiers ou textes AAAA)
    'facteurcarboneofficiel' => ['annee'], 'facteurcarbonesimple' => ['annee'],
    'facteurmobilite' => ['annee'], 'mobilitecarbone' => ['annee'],
    'gestionmateriel' => ['exercice'], 'archivesboite' => ['anneerevision'],
];
// Contenu des archives : documents historiques, seules les traces de saisie bougent.
$seulement = ['archivesdossier' => ['createdat', 'updatedat']];
$exclues   = ['documents' => ['donnees'], 'utilisateurs' => ['motdepasse', 'resettoken'],
              'configuration' => []];

// ── Inventaire du schéma ──────────────────────────────────────────────────
$tables = $pg
    ? $pdo->query("SELECT tablename FROM pg_tables WHERE schemaname = current_schema() ORDER BY 1")->fetchAll(PDO::FETCH_COLUMN)
    : $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY 1")->fetchAll(PDO::FETCH_COLUMN);
$colonnes = function (string $t) use ($pdo, $pg): array {
    $out = [];
    if ($pg) {
        $st = $pdo->prepare("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = ? ORDER BY ordinal_position");
        $st->execute([$t]);
        foreach ($st->fetchAll() as $c) $out[(string)$c['column_name']] = strtolower((string)$c['data_type']);
    } else {
        foreach ($pdo->query('PRAGMA table_info("' . $t . '")')->fetchAll() as $c) $out[(string)$c['name']] = strtolower((string)$c['type']);
    }
    return $out;
};

// ── Application ───────────────────────────────────────────────────────────
$bilan = [];
$pdo->beginTransaction();
try {
    foreach ($tables as $t) {
        $l = strtolower((string)$t);
        $cols = $colonnes((string)$t);
        $id = null;
        foreach ($cols as $c => $_) if (strtolower($c) === 'id') { $id = $c; break; }
        if ($id === null) continue;

        $texte = [];
        foreach ($cols as $c => $type) {
            $lc = strtolower($c);
            if ($lc === 'id' || in_array($lc, $exclues[$l] ?? [], true)) continue;
            if (isset($seulement[$l]) && !in_array($lc, $seulement[$l], true)) continue;
            $estTexte = $pg ? in_array($type, ['text', 'character varying', 'character'], true)
                            : ($type === '' || str_contains($type, 'char') || str_contains($type, 'text') || str_contains($type, 'clob'));
            $estAnnee = in_array($lc, $colonnesAnnee[$l] ?? [], true);
            if ($estTexte || $estAnnee) $texte[] = $c;
        }
        if ($texte === []) continue;

        // Colonnes « année » : en deux temps, pour ne jamais heurter un index
        // d'unicité (Annee, Type) pendant le décalage.
        foreach ($colonnesAnnee[$l] ?? [] as $ca) {
            if ($dy === 0) break;
            $reelle = null;
            foreach ($cols as $c => $_) if (strtolower($c) === $ca) $reelle = $c;
            if ($reelle === null) continue;
            $qt = $q((string)$t); $qc = $q($reelle); $k = 10000 + $dy;
            if ($pg && in_array($cols[$reelle], ['integer', 'bigint', 'smallint'], true)) {
                $u1 = "UPDATE $qt SET $qc = $qc + $k WHERE $qc BETWEEN 1990 AND 2099";
                $u2 = "UPDATE $qt SET $qc = $qc - 10000 WHERE $qc > 10000";
            } elseif ($pg) {
                $u1 = "UPDATE $qt SET $qc = (CAST($qc AS INTEGER) + $k)::text WHERE $qc ~ '^(19|20)[0-9]{2}$'";
                $u2 = "UPDATE $qt SET $qc = (CAST($qc AS INTEGER) - 10000)::text WHERE $qc ~ '^1[0-9]{4}$'";
            } else {
                $u1 = "UPDATE $qt SET $qc = CAST($qc AS INTEGER) + $k WHERE CAST($qc AS TEXT) GLOB '[12][09][0-9][0-9]'";
                $u2 = "UPDATE $qt SET $qc = CAST($qc AS INTEGER) - 10000 WHERE CAST($qc AS TEXT) GLOB '1[0-9][0-9][0-9][0-9]'";
            }
            if (!$simuler) { $pdo->exec($u1); $pdo->exec($u2); }
            $bilan[$t . '.' . $reelle . ' (année)'] = 'colonne';
        }

        $aLire = array_values(array_filter($texte, fn($c) => !in_array(strtolower($c), $colonnesAnnee[$l] ?? [], true)));
        if ($aLire === []) continue;
        $selection = implode(', ', array_map($q, array_merge([$id], $aLire)));
        $lecture = $pdo->query("SELECT $selection FROM " . $q((string)$t));
        $maj = [];
        while (($row = $lecture->fetch()) !== false) {
            $changes = [];
            foreach ($row as $c => $v) {
                if (strtolower((string)$c) === 'id' || !is_string($v) || $v === '') continue;
                $n = $decalerDates($v);
                $n = $numerosMois($n);
                $pref = $colonnesNumeroAnnee[$l][strtolower((string)$c)] ?? null;
                if ($pref !== null) $n = $numeroAnnee($n, $pref);
                if ($n !== $v) $changes[$c] = $n;
            }
            if ($changes) $maj[] = [$row[$id], $changes];
        }
        $lecture = null;
        foreach ($maj as [$cle, $changes]) {
            if (!$simuler) {
                $sets = implode(', ', array_map(fn($c) => $q((string)$c) . ' = ?', array_keys($changes)));
                $st = $pdo->prepare("UPDATE " . $q((string)$t) . " SET $sets WHERE " . $q($id) . " = ?");
                $st->execute(array_merge(array_values($changes), [$cle]));
            }
        }
        if ($maj) $bilan[(string)$t] = count($maj);
    }

    // Nouvelle référence
    if (!$simuler) {
        $st = $pdo->prepare("UPDATE " . $q('Configuration') . " SET " . $q('Valeur') . " = ? WHERE " . $q('Cle') . " = 'demo_ancre'");
        $st->execute([$nouvelleAncre]);
        if ($st->rowCount() === 0) {
            $pdo->prepare("INSERT INTO " . $q('Configuration') . " (" . $q('Cle') . ", " . $q('Valeur') . ", " . $q('Description') . ") VALUES ('demo_ancre', ?, ?)")
                ->execute([$nouvelleAncre, 'Fin de la période racontée par la démonstration (recaler-dates.php).']);
        }
    }
    $simuler ? $pdo->rollBack() : $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    fwrite(STDERR, "Échec — aucune modification : " . $e->getMessage() . "\n");
    exit(1);
}

// ── Fichiers de l'installation ────────────────────────────────────────────
if (isset($opt['fichiers']) && is_string($opt['fichiers'])) {
    foreach (['data/extensions/etat.json', 'data/thematiques/.etat.json'] as $rel) {
        $f = rtrim($opt['fichiers'], '/\\') . '/' . $rel;   // « C:\Larka\ » comme « /var/www/larka/ »
        if (!is_file($f)) continue;
        $avant = (string)file_get_contents($f);
        $apres = $decalerDates($avant);
        if ($apres !== $avant) {
            if (!$simuler) file_put_contents($f, $apres);
            $bilan[$rel] = 'fichier';
        }
    }
}

foreach ($bilan as $k => $v) printf("  %-44s %s\n", $k, is_int($v) ? "$v ligne(s)" : $v);
echo $simuler ? "Simulation : rien n'a été écrit.\n"
              : "Terminé. Si un serveur tournait, redémarrez-le ; reconnectez-vous.\n";
